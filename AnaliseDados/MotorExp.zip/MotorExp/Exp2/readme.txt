Objetivo: Obter Req, Leq, Vo. Utiliza-se um resistor conhecido em série com o motor e mede-se a corrente e a
constante de tempo do sinal aplicando um degrau na entrada.
Considerações: PWM = 100% e velocidade = 0
Usando o osciloscópio 
