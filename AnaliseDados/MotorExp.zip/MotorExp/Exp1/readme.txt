Objetivo: Determinar a corrente de controle do motor variando a entrada de tensão.
Condições: PWM = 0% e omega = 0%
